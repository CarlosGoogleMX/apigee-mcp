
var mcpToolsInfo = {
  "get-v3_covid_19_all": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/all",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["yesterday","twoDaysAgo","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_apple_countries": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/apple/countries",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_apple_countries_country": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/apple/countries/{country}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country"],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_apple_countries_country_subregions": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/apple/countries/{country}/{subregions}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country","subregions"],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_continents": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/continents",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["yesterday","twoDaysAgo","sort","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_continents_continent": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/continents/{continent}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["continent"],
       "query": ["yesterday","twoDaysAgo","strict","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_countries": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/countries",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["yesterday","twoDaysAgo","sort","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_countries_countries": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/countries/{countries}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["countries"],
       "query": ["yesterday","twoDaysAgo","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_countries_country": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/countries/{country}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country"],
       "query": ["yesterday","twoDaysAgo","strict","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_gov": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/gov/",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_gov_country": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/gov/{country}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": ""
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country"],
       "query": ["allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_all": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/all",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_countries": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/{countries}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["countries"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_country": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/{country}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_country_province": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/{country}/{province}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country","province"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_country_provinces": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/{country}/{provinces}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country","provinces"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_usacounties": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/usacounties",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_historical_usacounties_state": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/historical/usacounties/{state}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["state"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_jhucsse": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/jhucsse",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_jhucsse_counties": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/jhucsse/counties",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_jhucsse_counties_county": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/jhucsse/counties/{county}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["county"],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_nyt_counties": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/nyt/counties",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_nyt_counties_county": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/nyt/counties/{county}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["county"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_nyt_states": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/nyt/states",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_nyt_states_state": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/nyt/states/{state}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["state"],
       "query": ["lastdays"],
       "headers": []
    }
  },

  "get-v3_covid_19_nyt_usa": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/nyt/usa",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_states": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/states",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["sort","yesterday","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_states_states": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/states/{states}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["states"],
       "query": ["yesterday","allowNull"],
       "headers": []
    }
  },

  "get-v3_covid_19_therapeutics": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/therapeutics",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_vaccine": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/vaccine",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_vaccine_coverage": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/vaccine/coverage",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays","fullData"],
       "headers": []
    }
  },

  "get-v3_covid_19_vaccine_coverage_countries": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/vaccine/coverage/countries",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays","fullData"],
       "headers": []
    }
  },

  "get-v3_covid_19_vaccine_coverage_countries_country": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/vaccine/coverage/countries/{country}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country"],
       "query": ["lastdays","fullData"],
       "headers": []
    }
  },

  "get-v3_covid_19_vaccine_coverage_states": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/vaccine/coverage/states",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": ["lastdays","fullData"],
       "headers": []
    }
  },

  "get-v3_covid_19_vaccine_coverage_states_state": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/vaccine/coverage/states/{state}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["state"],
       "query": ["lastdays","fullData"],
       "headers": []
    }
  },

  "get-v3_covid_19_variants_countries": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/variants/countries/",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_covid_19_variants_countries_country": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/covid-19/variants/countries/{country}",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": ["country"],
       "query": ["allowNull"],
       "headers": []
    }
  },

  "get-v3_influenza_cdc_ilinet": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/influenza/cdc/ILINet",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_influenza_cdc_uscl": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/influenza/cdc/USCL",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  },

  "get-v3_influenza_cdc_usphl": {
    "target": {
      "url": "https://disease.sh/",
      "pathSuffix": "/v3/influenza/cdc/USPHL",
      "verb": "GET",
      "headers": {
        "content-type": "",
        "accept": "application/json"
     }
   },
    "schemas": {
      "request": {}
    },
    "inputParams": {
       "body": "",
       "path": [],
       "query": [],
       "headers": []
    }
  }

};